# Casino Sim — Demo Only (Single HTML)

A no-real-money, single-file casino simulation.  
**Games:** Mines • Dice • Plinko • Blackjack • Roulette (animated wheel + ball + table betting + favorites) • Keno • Slots.

> ⚠️ This is **not** gambling software. No accounts, no deposits, no prizes.

## Upload from your phone (Chrome)
1. Create a new repo on GitHub.
2. Tap **Add file → Upload files** and upload **index.html** (this single file is enough).  
   - Or upload the full ZIP and extract via desktop later.
3. (Optional) Enable **GitHub Pages**: Settings → Pages → Source: *Deploy from a branch*, Branch: `main`, Folder: `/ (root)`.

## Local use
Just open `index.html` in a browser.

## Notes
- Everything runs client-side.
- If audio doesn’t play on mobile, tap once anywhere to grant audio permission.
